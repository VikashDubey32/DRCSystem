package com.drcsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.drcsystem.dto.LoginDto;
import com.drcsystem.dto.StudentDto;
import com.drcsystem.dto.TeacherDto;
import com.drcsystem.entity.Student;
import com.drcsystem.entity.Teacher;
import com.drcsystem.service.StudentService;
import com.drcsystem.service.TeacherService;

@RestController
@RequestMapping("/api")
public class TeacherStudentController {
	
	@Autowired
    private  TeacherService teacherService;
	@Autowired
    private StudentService studentService;

//    public TeacherStudentController(TeacherService teacherService, StudentService studentService) {
//        this.teacherService = teacherService;
//        this.studentService = studentService;
//    }

    @PostMapping("/teachers")
    public Teacher signUpTeacher(@RequestBody TeacherDto teacherDto) {
        return teacherService.signUpTeacher(
                teacherDto.getEmail(),
                teacherDto.getPassword(),
                teacherDto.getName(),
                teacherDto.getUsername(),
                teacherDto.getGender(),
                teacherDto.getAge()
        );
    }

    @PostMapping("/teachers/login")
    public Teacher loginTeacher(@RequestBody LoginDto loginDto) {
        return teacherService.loginTeacher(loginDto.getEmail(), loginDto.getPassword());
    }

    @PostMapping("/students")
    public Student addStudent(@RequestBody StudentDto studentDto) {
        return studentService.addStudent(
                studentDto.getName(),
                studentDto.getRollNo(),
                studentDto.getDepartment(),
                studentDto.getStandard(),
                studentDto.getGender(),
                studentDto.getAge()
        );
    }

    @PutMapping("/students/{id}")
    public Student editStudent(@PathVariable int id, @RequestBody StudentDto studentDto) {
        return studentService.editStudent(
                id,
                studentDto.getName(),
                studentDto.getRollNo(),
                studentDto.getDepartment(),
                studentDto.getStandard(),
                studentDto.getGender(),
                studentDto.getAge()
        );
    }

    @GetMapping("/students/{id}")
    public Student getStudentById(@PathVariable int id) {
        return studentService.getStudentById(id);
    }

    @GetMapping("/students")
    public List<Student> getAllStudents(@RequestParam(defaultValue = "0") int page,
                                        @RequestParam(defaultValue = "10") int size) {
        return studentService.getAllStudents(page, size);
    }
}

