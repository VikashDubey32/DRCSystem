package com.drcsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.drcsystem.entity.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer> {
 // Additional methods if needed
}
