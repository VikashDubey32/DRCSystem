package com.drcsystem.service;

import java.awt.print.Pageable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.drcsystem.entity.Student;
import com.drcsystem.repository.StudentRepository;

@Service
public class StudentService {
	
	@Autowired
    private StudentRepository studentRepository;

   

    public Student addStudent(String name, String rollNo, String department, String standard, String gender, int age) {
        Student student = new Student();
        student.setName(name);
        student.setRollNo(rollNo);
        student.setDepartment(department);
        student.setStandard(standard);
        student.setGender(gender);
        student.setAge(age);
        return studentRepository.save(student);
    }

    public Student editStudent(int id, String name, String rollNo, String department, String standard, String gender, int age) {
        Student student = studentRepository.findById(id).orElse(null);
        if (student != null) {
            student.setName(name);
            student.setRollNo(rollNo);
            student.setDepartment(department);
            student.setStandard(standard);
            student.setGender(gender);
            student.setAge(age);
            return studentRepository.save(student);
        }
        return null;
    }

    public Student getStudentById(int id) {
        return studentRepository.findById(id).orElse(null);
    }

    public List<Student> getAllStudents(int page, int size) {
        Pageable pageable = (Pageable) PageRequest.of(page, size);
        Page<Student> studentPage =(Page<Student>) studentRepository.findAll((Sort) pageable);
        return studentPage.getContent();
    }
}
