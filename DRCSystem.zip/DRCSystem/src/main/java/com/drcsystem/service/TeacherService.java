package com.drcsystem.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.drcsystem.entity.Teacher;
import com.drcsystem.repository.TeacherRepository;

@Service
public class TeacherService {
    private final TeacherRepository teacherRepository;
    private final PasswordEncoder passwordEncoder;

    public TeacherService(TeacherRepository teacherRepository, PasswordEncoder passwordEncoder) {
        this.teacherRepository = teacherRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public Teacher signUpTeacher(String email, String password, String name, String username, String gender, int age) {
        String encryptedPassword = passwordEncoder.encode(password);
        Teacher teacher = new Teacher();
        teacher.setEmail(email);
        teacher.setPassword(encryptedPassword);
        teacher.setName(name);
        teacher.setUsername(username);
        teacher.setGender(gender);
        teacher.setAge(age);
        return teacherRepository.save(teacher);
    }

    public Teacher loginTeacher(String email, String password) {
        Teacher teacher = teacherRepository.findByEmail(email);
        if (teacher != null && passwordEncoder.matches(password, teacher.getPassword())) {
            return teacher;
        }
        return null;
    }
}

